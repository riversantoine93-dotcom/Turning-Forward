-- Run this once in Supabase Dashboard → SQL Editor.

create table if not exists public.course_progress (
  user_id uuid not null references auth.users(id) on delete cascade,
  course_slug text not null default 'turning-forward',
  progress jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  primary key (user_id, course_slug)
);

alter table public.course_progress enable row level security;

drop policy if exists "Students can read their own progress" on public.course_progress;
create policy "Students can read their own progress"
on public.course_progress for select
using (auth.uid() = user_id);

drop policy if exists "Students can insert their own progress" on public.course_progress;
create policy "Students can insert their own progress"
on public.course_progress for insert
with check (auth.uid() = user_id);

drop policy if exists "Students can update their own progress" on public.course_progress;
create policy "Students can update their own progress"
on public.course_progress for update
using (auth.uid() = user_id)
with check (auth.uid() = user_id);
